module.exports = {
  tokenBot: "TOKEN BOT LU",
  ownerID: "8116742353",
};
